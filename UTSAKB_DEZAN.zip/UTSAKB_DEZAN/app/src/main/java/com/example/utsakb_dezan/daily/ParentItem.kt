package com.example.utsakb_dezan.daily

    //Dezan Daffa Ramadhan
    //10120270
    //IF-7

data class ParentItem(val title : String , val logo : Int , val mList : List<ChildItem>)
