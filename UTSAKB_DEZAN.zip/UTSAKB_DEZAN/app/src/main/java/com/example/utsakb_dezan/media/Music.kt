package com.example.utsakb_dezan.media

    //Dezan Daffa Ramadhan
    //10120270
    //IF-7

data class Music(val title: String, val artist: String, val coverImage: Int)
