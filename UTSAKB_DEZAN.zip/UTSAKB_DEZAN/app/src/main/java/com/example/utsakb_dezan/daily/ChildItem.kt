package com.example.utsakb_dezan.daily

    //Dezan Daffa Ramadhan
    //10120270
    //IF-7

data class ChildItem(val title : String , val logo : Int)
