package com.example.utsakb_dezan.media

    //Dezan Daffa Ramadhan
    //10120270
    //IF-7

data class Video(val title: String, val videoUrl: String, val thumbnailImage: Int)